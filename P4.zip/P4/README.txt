Mia Belliveau 10824752

Graded

C++

Linux

Parses inputs and calculates values, main calls a function, plus other helpers. 
All in one *.cpp file

1. On a linux machine open terminal
2. cd into P4 directory
3. enter g++ compute_a_posteriori.cpp <observations>
	where <observations> is the sequence of evidence characters

